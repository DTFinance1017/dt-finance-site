import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { DorSection } from "@/components/DorSection";
import { AntesDepois } from "@/components/AntesDepois";
import { Services } from "@/components/Services";
import { HowItWorks } from "@/components/HowItWorks";
import { GanhosPraticos } from "@/components/GanhosPraticos";
import { Differentials } from "@/components/Differentials";
import { CasoIlustrativo } from "@/components/CasoIlustrativo";
import { ForWhom } from "@/components/ForWhom";
import { QuemSomos } from "@/components/QuemSomos";
import { CTA } from "@/components/CTA";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#040c1c]">
      <Navbar />
      <Hero />
      <DorSection />
      <AntesDepois />
      <GanhosPraticos />
      <HowItWorks />
      <Services />
      <Differentials />
      <CasoIlustrativo />
      <ForWhom />
      <QuemSomos />
      <CTA />
      <Footer />
    </div>
  );
}
