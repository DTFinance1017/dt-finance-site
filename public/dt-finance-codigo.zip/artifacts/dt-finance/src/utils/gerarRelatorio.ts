import { jsPDF } from "jspdf";
import { historico, forecast } from "../components/dashboard/AnaliseAnual";

async function logoBase64(): Promise<string> {
  const res = await fetch("/logo-dt-v2.png");
  const blob = await res.blob();
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.readAsDataURL(blob);
  });
}

function hexToRgb(hex: string) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return { r, g, b };
}

function tint(c: { r: number; g: number; b: number }, amount = 0.92) {
  return {
    r: Math.round(c.r + (255 - c.r) * amount),
    g: Math.round(c.g + (255 - c.g) * amount),
    b: Math.round(c.b + (255 - c.b) * amount),
  };
}

export type ReportType = "Executivo" | "DRE" | "Caixa" | "Alertas";

const reportTitles: Record<ReportType, string> = {
  Executivo: "Relatório Executivo",
  DRE: "DRE Gerencial",
  Caixa: "Análise de Caixa",
  Alertas: "Alertas Financeiros",
};

export async function gerarRelatorio(
  type: ReportType,
  periodo: string,
  _reportName: string
) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210;
  const navy    = hexToRgb("#040c1c");
  const navyMid = hexToRgb("#07132a");
  const blue    = hexToRgb("#3b82f6");
  const gold    = hexToRgb("#f0c040");
  const emerald = hexToRgb("#10b981");
  const amber   = hexToRgb("#d97706");
  const slate   = hexToRgb("#64748b");
  const red     = hexToRgb("#ef4444");

  /* ── Header background ── */
  doc.setFillColor(navy.r, navy.g, navy.b);
  doc.rect(0, 0, W, 42, "F");

  /* ── Accent bar ── */
  doc.setFillColor(blue.r, blue.g, blue.b);
  doc.rect(0, 42, W, 1.2, "F");

  /* ── Logo (905×323 px → ratio 2.8:1; render at 34×12 mm) ── */
  try {
    const logo = await logoBase64();
    doc.addImage(logo, "PNG", 14, 15, 34, 12);
  } catch (_) { /* skip if logo fails */ }

  /* ── Company name ── */
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.setTextColor(255, 255, 255);
  doc.text("DT Finance", 52, 18);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(180, 200, 220);
  doc.text("Dados e Tecnologia para Inteligência Financeira", 52, 24);

  /* ── Report title (right side) ── */
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(gold.r, gold.g, gold.b);
  doc.text(reportTitles[type], W - 14, 17, { align: "right" });

  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(140, 170, 200);
  doc.text(periodo, W - 14, 23, { align: "right" });

  doc.setFontSize(6.5);
  doc.setTextColor(100, 130, 160);
  doc.text(
    `Gerado em ${new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}`,
    W - 14, 37, { align: "right" }
  );

  let y = 52;

  /* ── Company info band ── */
  doc.setFillColor(navyMid.r, navyMid.g, navyMid.b);
  doc.roundedRect(14, y, W - 28, 12, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text("Empresa ABC Ltda", 20, y + 5);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(150, 180, 210);
  doc.text("CNPJ 00.000.000/0001-00  ·  Março 2025  ·  CONFIDENCIAL — uso exclusivo da diretoria", 20, y + 9.5);
  y += 18;

  /* ── Helper: section title ── */
  function sectionTitle(title: string, yPos: number) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(blue.r, blue.g, blue.b);
    doc.text(title, 14, yPos);
    doc.setDrawColor(blue.r, blue.g, blue.b);
    doc.setLineWidth(0.4);
    doc.line(14, yPos + 1.5, W - 14, yPos + 1.5);
    return yPos + 8;
  }

  /* ── KPIs ── */
  y = sectionTitle("INDICADORES EXECUTIVOS — MARÇO 2025", y);

  const kpis = [
    { label: "Receita Bruta",          value: "R$ 2.840.000", change: "+12,4% vs mês anterior", color: blue,    good: true  },
    { label: "Margem EBITDA",           value: "31,4%",        change: "+2,1pp vs mês anterior", color: emerald, good: true  },
    { label: "Caixa Disponível",        value: "R$ 1.120.000", change: "-5,2% vs mês anterior",  color: amber,   good: false },
    { label: "Índice de Inadimplência", value: "3,2%",         change: "-0,8pp vs mês anterior", color: emerald, good: true  },
    { label: "Receita Recorrente (MRR)",value: "R$ 1.950.000", change: "+8,7% vs mês anterior",  color: blue,    good: true  },
    { label: "Custo Fixo Total",        value: "R$ 680.000",   change: "+1,2% vs mês anterior",  color: amber,   good: false },
    { label: "Ticket Médio",            value: "R$ 42.500",    change: "+3,8% vs mês anterior",  color: blue,    good: true  },
    { label: "Resultado Líquido",       value: "R$ 412.000",   change: "+18,3% vs mês anterior", color: emerald, good: true  },
  ];

  const colW = (W - 28 - 9) / 4;
  const kpiRows = [kpis.slice(0, 4), kpis.slice(4, 8)];

  for (const row of kpiRows) {
    for (let i = 0; i < row.length; i++) {
      const kpi = row[i];
      const x   = 14 + i * (colW + 3);
      const c   = kpi.color;
      const bg  = tint(c, 0.92);

      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.roundedRect(x, y, colW, 20, 2, 2, "F");

      const borderColor = tint(c, 0.75);
      doc.setDrawColor(borderColor.r, borderColor.g, borderColor.b);
      doc.setLineWidth(0.3);
      doc.roundedRect(x, y, colW, 20, 2, 2, "S");

      doc.setFont("helvetica", "normal");
      doc.setFontSize(6.5);
      doc.setTextColor(100, 120, 150);
      doc.text(kpi.label, x + 3, y + 5.5);

      doc.setFont("helvetica", "bold");
      doc.setFontSize(9.5);
      doc.setTextColor(20, 30, 50);
      doc.text(kpi.value, x + 3, y + 12);

      const cc = kpi.good ? emerald : amber;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(6);
      doc.setTextColor(cc.r, cc.g, cc.b);
      doc.text(kpi.change, x + 3, y + 17.5);
    }
    y += 24;
  }

  y += 4;

  /* ── DRE ── */
  if (type === "Executivo" || type === "DRE") {
    y = sectionTitle("DEMONSTRATIVO DE RESULTADO — DRE GERENCIAL", y);

    const dreRows = [
      { label: "Receita Bruta de Vendas",       mar: "2.840.000",   fev: "2.520.000",   jan: "2.380.000",   bold: false, indent: 0,  highlight: false },
      { label: "(-) Deduções e Impostos",        mar: "(284.000)",   fev: "(252.000)",   jan: "(238.000)",   bold: false, indent: 0,  highlight: false },
      { label: "Receita Líquida",                mar: "2.556.000",   fev: "2.268.000",   jan: "2.142.000",   bold: true,  indent: 0,  highlight: false },
      { label: "(-) Custo dos Produtos/Serviços",mar: "(1.024.000)", fev: "(924.000)",   jan: "(876.000)",   bold: false, indent: 0,  highlight: false },
      { label: "Lucro Bruto",                    mar: "1.532.000",   fev: "1.344.000",   jan: "1.266.000",   bold: true,  indent: 0,  highlight: true  },
      { label: "(-) Despesas Operacionais",      mar: "(988.000)",   fev: "(876.000)",   jan: "(834.000)",   bold: false, indent: 0,  highlight: false },
      { label: "Salários e Encargos",            mar: "(520.000)",   fev: "(490.000)",   jan: "(490.000)",   bold: false, indent: 6,  highlight: false },
      { label: "Despesas Comerciais",            mar: "(218.000)",   fev: "(196.000)",   jan: "(194.000)",   bold: false, indent: 6,  highlight: false },
      { label: "Despesas Administrativas",       mar: "(250.000)",   fev: "(190.000)",   jan: "(150.000)",   bold: false, indent: 6,  highlight: false },
      { label: "EBITDA",                         mar: "892.800",     fev: "781.200",     jan: "734.400",     bold: true,  indent: 0,  highlight: true  },
      { label: "Margem EBITDA",                  mar: "31,4%",       fev: "30,9%",       jan: "30,8%",       bold: true,  indent: 0,  highlight: true  },
      { label: "(-) Depreciação e Amortização",  mar: "(48.000)",    fev: "(48.000)",    jan: "(48.000)",    bold: false, indent: 0,  highlight: false },
      { label: "EBIT",                           mar: "844.800",     fev: "733.200",     jan: "686.400",     bold: false, indent: 0,  highlight: false },
      { label: "(-) Resultado Financeiro",       mar: "(82.000)",    fev: "(76.000)",    jan: "(68.000)",    bold: false, indent: 0,  highlight: false },
      { label: "Resultado Antes do IR",          mar: "762.800",     fev: "657.200",     jan: "618.400",     bold: false, indent: 0,  highlight: false },
      { label: "(-) IRPJ e CSLL",               mar: "(350.800)",   fev: "(309.400)",   jan: "(286.400)",   bold: false, indent: 0,  highlight: false },
      { label: "Resultado Líquido",              mar: "412.000",     fev: "347.800",     jan: "332.000",     bold: true,  indent: 0,  highlight: true  },
      { label: "Margem Líquida",                 mar: "14,5%",       fev: "13,8%",       jan: "13,9%",       bold: true,  indent: 0,  highlight: true  },
    ];

    const headers = ["", "Mar/25", "Fev/25", "Jan/25"];
    const cw      = [85, 28, 28, 28];
    const xs      = [14, 99, 127, 155];

    doc.setFillColor(navy.r, navy.g, navy.b);
    doc.rect(14, y, W - 28, 7, "F");
    headers.forEach((h, i) => {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7);
      doc.setTextColor(180, 200, 220);
      doc.text(h, xs[i] + (i > 0 ? cw[i] : 0), y + 4.5, { align: i > 0 ? "right" : "left" });
    });
    y += 7;

    dreRows.forEach((row, idx) => {
      const bg = row.highlight
        ? { r: 235, g: 245, b: 255 }
        : idx % 2 === 0
        ? { r: 250, g: 251, b: 255 }
        : { r: 244, g: 246, b: 252 };

      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.rect(14, y, W - 28, 6.5, "F");

      doc.setFont("helvetica", row.bold ? "bold" : "normal");
      doc.setFontSize(7);
      const tc = row.bold ? { r: 10, g: 20, b: 50 } : { r: 60, g: 80, b: 110 };
      doc.setTextColor(tc.r, tc.g, tc.b);
      doc.text(row.label, xs[0] + row.indent, y + 4.2);

      [row.mar, row.fev, row.jan].forEach((val, vi) => {
        const isNeg = val.startsWith("(") || val.startsWith("-");
        let vc = isNeg ? amber : (row.highlight ? emerald : (row.bold ? blue : { r: 50, g: 70, b: 100 }));
        doc.setTextColor(vc.r, vc.g, vc.b);
        doc.setFont("helvetica", row.bold ? "bold" : "normal");
        doc.text(val, xs[vi + 1] + cw[vi + 1], y + 4.2, { align: "right" });
      });

      doc.setDrawColor(220, 225, 235);
      doc.setLineWidth(0.1);
      doc.line(14, y + 6.5, W - 14, y + 6.5);
      y += 6.5;
    });
    y += 6;
  }

  /* ── Cash Flow ── */
  if (type === "Executivo" || type === "Caixa") {
    if (y > 230) { doc.addPage(); y = 20; }
    y = sectionTitle("ANÁLISE DE FLUXO DE CAIXA", y);

    const cfRows = [
      { label: "Saldo Inicial (01/03/2025)",      value: "R$ 1.218.400",  type: "neutral"  },
      { label: "Entradas Operacionais",            value: "+ R$ 2.640.000",type: "positive" },
      { label: "Saídas Operacionais",              value: "- R$ 1.892.000",type: "negative" },
      { label: "Resultado Operacional Líquido",    value: "R$ 748.000",    type: "positive" },
      { label: "Entradas Financeiras",             value: "+ R$ 12.400",   type: "positive" },
      { label: "Saídas Financeiras",               value: "- R$ 82.000",   type: "negative" },
      { label: "Amortizações e Financiamentos",    value: "- R$ 376.800",  type: "negative" },
      { label: "Saldo Final (31/03/2025)",         value: "R$ 1.120.000",  type: "total"    },
    ];

    cfRows.forEach((row) => {
      if (row.type === "total") {
        doc.setFillColor(navy.r, navy.g, navy.b);
        doc.roundedRect(14, y, W - 28, 8, 1.5, 1.5, "F");
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        doc.setTextColor(255, 255, 255);
        doc.text(row.label, 20, y + 5.2);
        doc.setTextColor(gold.r, gold.g, gold.b);
        doc.text(row.value, W - 20, y + 5.2, { align: "right" });
        y += 10;
      } else {
        doc.setFillColor(250, 251, 255);
        doc.rect(14, y, W - 28, 6.5, "F");
        doc.setFont("helvetica", "normal");
        doc.setFontSize(7.5);
        doc.setTextColor(60, 80, 110);
        doc.text(row.label, 20, y + 4.2);
        const vc = row.type === "positive" ? emerald : row.type === "negative" ? amber : slate;
        doc.setTextColor(vc.r, vc.g, vc.b);
        doc.setFont("helvetica", "bold");
        doc.text(row.value, W - 20, y + 4.2, { align: "right" });
        doc.setDrawColor(220, 225, 235);
        doc.setLineWidth(0.1);
        doc.line(14, y + 6.5, W - 14, y + 6.5);
        y += 6.5;
      }
    });
    y += 6;
  }

  /* ── Alerts ── */
  if (type === "Executivo" || type === "Alertas") {
    if (y > 230) { doc.addPage(); y = 20; }
    y = sectionTitle("ALERTAS E PONTOS DE ATENÇÃO", y);

    const alerts = [
      { level: "CRÍTICO",  color: red,     text: "Concentração de recebíveis: Grupo Alpha representa 38% da Receita Bruta — risco de concentração elevado. Recomenda-se diversificação comercial urgente." },
      { level: "ATENÇÃO",  color: amber,   text: "Caixa disponível recuou 5,2% em março. Projeção para abril indica necessidade de capital de giro adicional de R$ 180.000 caso inadimplência se mantenha." },
      { level: "ATENÇÃO",  color: amber,   text: "Despesas administrativas cresceram 31,6% vs janeiro/25. Revisão de contratos e fornecedores recomendada para o próximo trimestre." },
      { level: "POSITIVO", color: emerald, text: "Margem EBITDA atingiu 31,4% — melhor resultado dos últimos 6 meses. Eficiência operacional em expansão." },
      { level: "POSITIVO", color: emerald, text: "Inadimplência recuou para 3,2% (vs 4,0% em fevereiro). Ação de cobrança implementada em fevereiro apresentou resultado positivo." },
    ];

    alerts.forEach((alert) => {
      const bg = tint(alert.color, 0.90);
      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.roundedRect(14, y, W - 28, 14, 2, 2, "F");

      doc.setFillColor(alert.color.r, alert.color.g, alert.color.b);
      doc.roundedRect(14, y, 3, 14, 0.5, 0.5, "F");

      doc.setFont("helvetica", "bold");
      doc.setFontSize(6.5);
      doc.setTextColor(alert.color.r, alert.color.g, alert.color.b);
      doc.text(alert.level, 21, y + 5);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.setTextColor(40, 60, 90);
      const lines = doc.splitTextToSize(alert.text, W - 42);
      doc.text(lines, 21, y + 10);
      y += 17;
    });
    y += 4;
  }

  /* ── Análise Anual 2026 ── */
  if (type === "Executivo" || type === "DRE") {
    doc.addPage();
    y = 20;

    /* Page header stripe */
    doc.setFillColor(navy.r, navy.g, navy.b);
    doc.rect(0, 0, W, 14, "F");
    doc.setFillColor(gold.r, gold.g, gold.b);
    doc.rect(0, 14, W, 0.8, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(gold.r, gold.g, gold.b);
    doc.text("ANÁLISE ANUAL 2026 — META VS REALIZADO + FORECAST", 14, 9.5);
    y = 22;

    /* Compute derived values */
    const ytdMeses = historico.filter((h) => h.tipo === "ytd");
    const ytdMeta  = ytdMeses.reduce((s, h) => s + h.meta, 0);
    const ytdReal  = ytdMeses.reduce((s, h) => s + h.real, 0);
    const ytdPct   = (ytdReal / ytdMeta) * 100;
    const metaAnual= historico.reduce((s, h) => s + h.meta, 0) + forecast.reduce((s, f) => s + f.meta, 0);
    const projTotal= ytdReal + forecast.reduce((s, f) => s + f.proj, 0);
    const projPct  = (projTotal / metaAnual) * 100;

    function fmtK(v: number) { return v >= 1000 ? `R$ ${(v / 1000).toFixed(2).replace(".", ",")}M` : `R$ ${v}K`; }

    /* Summary KPI boxes */
    const summaryKpis = [
      { label: "YTD Receita (Jan–Mar/26)", value: fmtK(ytdReal), sub: `${ytdPct.toFixed(1)}% da meta YTD`, color: blue },
      { label: "Projeção Anual 2026",      value: fmtK(projTotal), sub: "Realizado + Forecast",             color: emerald },
      { label: "Meta Anual 2026",          value: fmtK(metaAnual), sub: "12 meses consolidado",             color: gold },
      { label: "Ating. Projetado",         value: `${projPct.toFixed(1)}%`, sub: projPct >= 100 ? "Acima da meta" : "Abaixo da meta", color: projPct >= 100 ? emerald : amber },
    ];
    const kW = (W - 28 - 9) / 4;
    summaryKpis.forEach((k, i) => {
      const x  = 14 + i * (kW + 3);
      const bg = tint(k.color, 0.90);
      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.roundedRect(x, y, kW, 20, 2, 2, "F");
      const border = tint(k.color, 0.75);
      doc.setDrawColor(border.r, border.g, border.b);
      doc.setLineWidth(0.3);
      doc.roundedRect(x, y, kW, 20, 2, 2, "S");
      doc.setFont("helvetica", "normal"); doc.setFontSize(6); doc.setTextColor(80, 100, 130);
      doc.text(k.label, x + 3, y + 5);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(k.color.r, k.color.g, k.color.b);
      doc.text(k.value, x + 3, y + 12);
      doc.setFont("helvetica", "normal"); doc.setFontSize(6); doc.setTextColor(100, 120, 150);
      doc.text(k.sub, x + 3, y + 17.5);
    });
    y += 25;

    /* Progress bar */
    doc.setFillColor(230, 235, 245);
    doc.roundedRect(14, y, W - 28, 7, 2, 2, "F");
    const barW = Math.min((projPct / 100) * (W - 28), W - 28);
    const barColor = projPct >= 100 ? emerald : blue;
    doc.setFillColor(barColor.r, barColor.g, barColor.b);
    doc.roundedRect(14, y, barW, 7, 2, 2, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(6.5); doc.setTextColor(255, 255, 255);
    if (barW > 30) doc.text(`${projPct.toFixed(1)}% da meta anual`, 18, y + 4.5);
    y += 10;
    doc.setFont("helvetica", "normal"); doc.setFontSize(7); doc.setTextColor(60, 80, 110);
    const ritmoText = projPct >= 100
      ? `No ritmo atual, a empresa projeta encerrar 2026 com ${fmtK(projTotal)} — ${(projPct - 100).toFixed(1)}% acima da meta anual de ${fmtK(metaAnual)}.`
      : `Atenção: ritmo atual projeta ${fmtK(projTotal)}, ficando ${fmtK(metaAnual - projTotal)} abaixo da meta de ${fmtK(metaAnual)}. Aceleração comercial recomendada.`;
    doc.text(doc.splitTextToSize(ritmoText, W - 28), 14, y);
    y += 10;

    /* ── Line Chart: Receita Realizado vs Forecast ── */
    if (y > 195) { doc.addPage(); y = 20; }
    y = sectionTitle("GRÁFICO — RECEITA BRUTA: REALIZADO VS FORECAST (OUT/25 – DEZ/26)", y);

    {
      const cLeft  = 32;
      const cRight = W - 14;
      const cPW    = cRight - cLeft;   // plot width (mm)
      const cPH    = 42;               // plot height (mm)
      const cBot   = y + cPH;

      const allMeta = [...historico.map(h => h.meta), ...forecast.map(f => f.meta)];
      const steps   = allMeta.length - 1; // 14

      function gx(i: number) { return cLeft + (i / steps) * cPW; }
      function gy(v: number) { return cBot - ((v - 2000) / 1500) * cPH; }

      /* Shaded forecast zone */
      const divXp = (gx(historico.length - 1) + gx(historico.length)) / 2;
      const fcBg  = tint(emerald, 0.93);
      doc.setFillColor(fcBg.r, fcBg.g, fcBg.b);
      doc.rect(divXp, y, cRight - divXp, cPH, "F");

      /* Grid lines */
      [2000, 2400, 2800, 3200].forEach((v) => {
        const gy_v = gy(v);
        doc.setDrawColor(210, 220, 235); doc.setLineWidth(0.15); doc.setLineDash([1, 2], 0);
        doc.line(cLeft, gy_v, cRight, gy_v);
        doc.setLineDash([], 0);
        doc.setFont("helvetica", "normal"); doc.setFontSize(5.8); doc.setTextColor(100, 120, 155);
        doc.text(`${(v / 1000).toFixed(1)}M`, cLeft - 1.5, gy_v + 1.8, { align: "right" });
      });

      /* Divider */
      doc.setLineDash([1.2, 1.5], 0); doc.setDrawColor(140, 165, 200); doc.setLineWidth(0.5);
      doc.line(divXp, y - 2, divXp, cBot + 4);
      doc.setLineDash([], 0);

      /* Legend (top-right) */
      [
        { lbl: "Meta",      color: { r: 150, g: 175, b: 210 }, dash: true  },
        { lbl: "Realizado", color: blue,                        dash: false },
        { lbl: "Forecast",  color: { r: 13, g: 148, b: 136 },  dash: true  },
      ].forEach((leg, i) => {
        const lx = cRight - 84 + i * 29;
        doc.setDrawColor(leg.color.r, leg.color.g, leg.color.b); doc.setLineWidth(0.9);
        if (leg.dash) doc.setLineDash([1.5, 1.5], 0); else doc.setLineDash([], 0);
        doc.line(lx, y - 5, lx + 8, y - 5);
        doc.setLineDash([], 0);
        doc.setFont("helvetica", "normal"); doc.setFontSize(6); doc.setTextColor(80, 105, 140);
        doc.text(leg.lbl, lx + 10, y - 3.5);
      });

      /* Divider labels */
      doc.setFontSize(5.8); doc.setTextColor(90, 115, 155);
      doc.text("◀ Realizado", divXp - 1.5, y - 2, { align: "right" });
      doc.setTextColor(13, 148, 136);
      doc.text("Forecast ▶", divXp + 1.5, y - 2);

      /* Meta line (dashed gray) */
      doc.setLineDash([1.5, 1.5], 0); doc.setDrawColor(150, 175, 210); doc.setLineWidth(0.7);
      for (let i = 0; i < steps; i++) {
        doc.line(gx(i), gy(allMeta[i]), gx(i + 1), gy(allMeta[i + 1]));
      }
      doc.setLineDash([], 0);

      /* Realizado line (solid blue) */
      doc.setDrawColor(blue.r, blue.g, blue.b); doc.setLineWidth(1.3);
      for (let i = 0; i < historico.length - 1; i++) {
        doc.line(gx(i), gy(historico[i].real), gx(i + 1), gy(historico[i + 1].real));
      }

      /* Projetado line (dashed teal) */
      doc.setLineDash([2, 1.5], 0); doc.setDrawColor(13, 148, 136); doc.setLineWidth(1.3);
      doc.line(gx(historico.length - 1), gy(historico[historico.length - 1].real), gx(historico.length), gy(forecast[0].proj));
      for (let i = 0; i < forecast.length - 1; i++) {
        doc.line(gx(historico.length + i), gy(forecast[i].proj), gx(historico.length + i + 1), gy(forecast[i + 1].proj));
      }
      doc.setLineDash([], 0);

      /* Realizado dots */
      historico.forEach((h, i) => {
        doc.setFillColor(blue.r, blue.g, blue.b);
        doc.circle(gx(i), gy(h.real), 1.0, "F");
      });

      /* Forecast dots */
      forecast.forEach((f, i) => {
        doc.setFillColor(13, 148, 136);
        doc.circle(gx(historico.length + i), gy(f.proj), 0.9, "F");
      });

      /* X-axis labels */
      const xLabels = ["Out", "Nov", "Dez", "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
      xLabels.forEach((lbl, i) => {
        doc.setFont("helvetica", "normal"); doc.setFontSize(5.5);
        doc.setTextColor(i < historico.length ? 80 : 13, i < historico.length ? 105 : 148, i < historico.length ? 150 : 136);
        doc.text(lbl, gx(i), cBot + 5, { align: "center" });
      });

      /* Year labels below */
      doc.setFontSize(5); doc.setTextColor(120, 140, 170);
      doc.text("2025", gx(1), cBot + 9, { align: "center" });
      doc.text("2026", gx(8), cBot + 9, { align: "center" });

      /* Axis baseline */
      doc.setDrawColor(190, 205, 225); doc.setLineWidth(0.3);
      doc.line(cLeft, cBot, cRight, cBot);

      y = cBot + 14;
    }

    /* ── Histórico table ── */
    y = sectionTitle("HISTÓRICO — META VS REALIZADO (OUT/25 – MAR/26)", y);

    const histHeaders = ["Mês", "Meta (R$K)", "Realizado (R$K)", "Variação (R$K)", "% Ating.", "Status", "Tipo"];
    const histCW      = [28, 30, 34, 30, 22, 22, 14];
    const histX       = [14, 42, 72, 106, 136, 158, 180];

    doc.setFillColor(navy.r, navy.g, navy.b);
    doc.rect(14, y, W - 28, 7, "F");
    histHeaders.forEach((h, i) => {
      doc.setFont("helvetica", "bold"); doc.setFontSize(6.5); doc.setTextColor(180, 200, 225);
      doc.text(h, i === 0 ? histX[i] + 1 : histX[i] + histCW[i], y + 4.5, { align: i === 0 ? "left" : "right" });
    });
    y += 7;

    historico.forEach((row, idx) => {
      const pct   = (row.real / row.meta) * 100;
      const delta = row.real - row.meta;
      const good  = pct >= 100;
      const bg    = row.tipo === "ytd"
        ? { r: 235, g: 245, b: 255 }
        : idx % 2 === 0 ? { r: 250, g: 251, b: 255 } : { r: 244, g: 246, b: 252 };
      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.rect(14, y, W - 28, 6.5, "F");

      const vals = [
        { t: row.mes,              align: "left"  as const, color: { r: 30, g: 50, b: 80 },  bold: true  },
        { t: row.meta.toLocaleString("pt-BR"), align: "right" as const, color: { r: 80, g: 100, b: 130 }, bold: false },
        { t: row.real.toLocaleString("pt-BR"), align: "right" as const, color: { r: 20, g: 40, b: 70 },  bold: true  },
        { t: (delta >= 0 ? "+" : "") + delta.toLocaleString("pt-BR"), align: "right" as const, color: delta >= 0 ? emerald : red, bold: true },
        { t: `${pct.toFixed(1)}%`, align: "right" as const, color: good ? emerald : pct >= 95 ? amber : red, bold: true },
        { t: good ? "✓ Meta" : pct >= 95 ? "~ Perto" : "✗ Abaixo", align: "right" as const, color: good ? emerald : pct >= 95 ? amber : red, bold: false },
        { t: row.tipo === "ytd" ? "YTD" : "Hist.", align: "right" as const, color: row.tipo === "ytd" ? blue : slate, bold: false },
      ];
      vals.forEach((v, i) => {
        doc.setFont("helvetica", v.bold ? "bold" : "normal");
        doc.setFontSize(7);
        doc.setTextColor(v.color.r, v.color.g, v.color.b);
        doc.text(v.t, i === 0 ? histX[i] + 1 : histX[i] + histCW[i], y + 4.2, { align: v.align });
      });
      doc.setDrawColor(215, 225, 238); doc.setLineWidth(0.1);
      doc.line(14, y + 6.5, W - 14, y + 6.5);
      y += 6.5;
    });

    /* YTD total row */
    doc.setFillColor(navy.r, navy.g, navy.b);
    doc.rect(14, y, W - 28, 8, "F");
    const ytdDelta = ytdReal - ytdMeta;
    [
      { t: "TOTAL YTD (Jan–Mar/26)", align: "left"  as const, color: { r: 255, g: 255, b: 255 }, x: histX[0] + 1 },
      { t: ytdMeta.toLocaleString("pt-BR"), align: "right" as const, color: { r: 180, g: 200, b: 225 }, x: histX[1] + histCW[1] },
      { t: ytdReal.toLocaleString("pt-BR"), align: "right" as const, color: { r: 255, g: 255, b: 255 }, x: histX[2] + histCW[2] },
      { t: (ytdDelta >= 0 ? "+" : "") + ytdDelta.toLocaleString("pt-BR"), align: "right" as const, color: ytdDelta >= 0 ? emerald : red, x: histX[3] + histCW[3] },
      { t: `${ytdPct.toFixed(1)}%`, align: "right" as const, color: gold, x: histX[4] + histCW[4] },
    ].forEach((v) => {
      doc.setFont("helvetica", "bold"); doc.setFontSize(7.5);
      doc.setTextColor(v.color.r, v.color.g, v.color.b);
      doc.text(v.t, v.x, y + 5.2, { align: v.align });
    });
    y += 12;

    /* ── Forecast table ── */
    y = sectionTitle("FORECAST — PROJEÇÃO ABR–DEZ/26", y);

    const fcHeaders = ["Mês", "Meta (R$K)", "Forecast (R$K)", "% vs Meta", "Indicação"];
    const fcCW      = [30, 35, 38, 28, 35];
    const fcX       = [14, 44, 79, 117, 145];

    doc.setFillColor(tint(emerald, 0.15).r, tint(emerald, 0.15).g, tint(emerald, 0.15).b);
    doc.rect(14, y, W - 28, 7, "F");
    fcHeaders.forEach((h, i) => {
      doc.setFont("helvetica", "bold"); doc.setFontSize(6.5); doc.setTextColor(20, 70, 50);
      doc.text(h, i === 0 ? fcX[i] + 1 : fcX[i] + fcCW[i], y + 4.5, { align: i === 0 ? "left" : "right" });
    });
    y += 7;

    forecast.forEach((row, idx) => {
      const pct  = (row.proj / row.meta) * 100;
      const good = pct >= 100;
      const bg   = idx % 2 === 0 ? { r: 248, g: 252, b: 250 } : { r: 241, g: 248, b: 244 };
      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.rect(14, y, W - 28, 6.5, "F");

      const vals = [
        { t: row.mes,    align: "left"  as const, color: { r: 30, g: 50, b: 80 },  bold: true  },
        { t: row.meta.toLocaleString("pt-BR"),  align: "right" as const, color: { r: 80, g: 100, b: 130 }, bold: false },
        { t: row.proj.toLocaleString("pt-BR"),  align: "right" as const, color: good ? emerald : amber, bold: true  },
        { t: `${pct.toFixed(1)}%`, align: "right" as const, color: good ? emerald : amber, bold: true },
        { t: good ? "▲ Acima da meta" : "▼ Abaixo da meta", align: "right" as const, color: good ? emerald : amber, bold: false },
      ];
      vals.forEach((v, i) => {
        doc.setFont("helvetica", v.bold ? "bold" : "normal");
        doc.setFontSize(7);
        doc.setTextColor(v.color.r, v.color.g, v.color.b);
        doc.text(v.t, i === 0 ? fcX[i] + 1 : fcX[i] + fcCW[i], y + 4.2, { align: v.align });
      });
      doc.setDrawColor(215, 235, 225); doc.setLineWidth(0.1);
      doc.line(14, y + 6.5, W - 14, y + 6.5);
      y += 6.5;
    });

    /* Forecast total row */
    const fcMetaTotal = forecast.reduce((s, f) => s + f.meta, 0);
    const fcProjTotal = forecast.reduce((s, f) => s + f.proj, 0);
    const fcPct       = (fcProjTotal / fcMetaTotal) * 100;
    doc.setFillColor(tint(emerald, 0.15).r, tint(emerald, 0.15).g, tint(emerald, 0.15).b);
    doc.rect(14, y, W - 28, 8, "F");
    [
      { t: "TOTAL FORECAST (Abr–Dez/26)", align: "left"  as const, color: { r: 20, g: 70, b: 50 }, x: fcX[0] + 1 },
      { t: fcMetaTotal.toLocaleString("pt-BR"), align: "right" as const, color: { r: 60, g: 100, b: 80 }, x: fcX[1] + fcCW[1] },
      { t: fcProjTotal.toLocaleString("pt-BR"), align: "right" as const, color: emerald, x: fcX[2] + fcCW[2] },
      { t: `${fcPct.toFixed(1)}%`, align: "right" as const, color: emerald, x: fcX[3] + fcCW[3] },
    ].forEach((v) => {
      doc.setFont("helvetica", "bold"); doc.setFontSize(7.5);
      doc.setTextColor(v.color.r, v.color.g, v.color.b);
      doc.text(v.t, v.x, y + 5.2, { align: v.align });
    });
    y += 12;

    /* Consolidated 2026 */
    if (y > 230) { doc.addPage(); y = 20; }
    y = sectionTitle("VISÃO CONSOLIDADA — RECEITA BRUTA 2026", y);

    const consItems = [
      { label: "Realizado YTD (Jan–Mar/26)", value: fmtK(ytdReal),     color: blue,    note: `${ytdPct.toFixed(1)}% da meta YTD` },
      { label: "Forecast Restante (Abr–Dez)", value: fmtK(fcProjTotal), color: emerald, note: "Baseado em tendência" },
      { label: "Projeção Total Anual",         value: fmtK(projTotal),  color: emerald, note: "Realizado + Forecast" },
      { label: "Meta Anual 2026",              value: fmtK(metaAnual),  color: gold,    note: `${projPct.toFixed(1)}% será atingido` },
    ];

    consItems.forEach((item, i) => {
      const x  = 14 + i * (kW + 3);
      const bg = tint(item.color, 0.88);
      doc.setFillColor(bg.r, bg.g, bg.b);
      doc.roundedRect(x, y, kW, 22, 2, 2, "F");
      const border = tint(item.color, 0.72);
      doc.setDrawColor(border.r, border.g, border.b);
      doc.setLineWidth(0.3);
      doc.roundedRect(x, y, kW, 22, 2, 2, "S");
      doc.setFont("helvetica", "normal"); doc.setFontSize(5.5); doc.setTextColor(80, 100, 130);
      const lns = doc.splitTextToSize(item.label, kW - 4);
      doc.text(lns, x + 2, y + 4.5);
      doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(item.color.r, item.color.g, item.color.b);
      doc.text(item.value, x + 2, y + 14);
      doc.setFont("helvetica", "normal"); doc.setFontSize(5.5); doc.setTextColor(100, 130, 160);
      doc.text(item.note, x + 2, y + 19.5);
    });
    y += 26;

    /* Conclusion box */
    const concBg = projPct >= 100 ? tint(emerald, 0.88) : tint(amber, 0.88);
    const concColor = projPct >= 100 ? emerald : amber;
    doc.setFillColor(concBg.r, concBg.g, concBg.b);
    doc.roundedRect(14, y, W - 28, 14, 2, 2, "F");
    doc.setFillColor(concColor.r, concColor.g, concColor.b);
    doc.roundedRect(14, y, 3, 14, 0.5, 0.5, "F");
    doc.setFont("helvetica", "bold"); doc.setFontSize(7); doc.setTextColor(concColor.r, concColor.g, concColor.b);
    doc.text(projPct >= 100 ? "RITMO ATUAL: META ANUAL EM CURSO" : "ATENÇÃO: RITMO ABAIXO DA META", 21, y + 5.5);
    doc.setFont("helvetica", "normal"); doc.setFontSize(6.8); doc.setTextColor(40, 60, 90);
    const concText = projPct >= 100
      ? `Com base no desempenho de Jan–Mar/26 e na projeção para os demais meses, a empresa tende a encerrar 2026 com ${fmtK(projTotal)}, representando ${projPct.toFixed(1)}% de atingimento da meta anual de ${fmtK(metaAnual)}.`
      : `O desempenho de Jan–Mar/26 indica projeção de ${fmtK(projTotal)} para o ano completo, abaixo da meta anual de ${fmtK(metaAnual)}. Recomenda-se aceleração comercial no 2º trimestre.`;
    doc.text(doc.splitTextToSize(concText, W - 42), 21, y + 10.5);
    y += 18;
  }

  /* ── Footer on every page ── */
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFillColor(navy.r, navy.g, navy.b);
    doc.rect(0, 285, W, 12, "F");
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);
    doc.setTextColor(120, 150, 185);
    doc.text(
      "DT Finance — Inteligência Financeira · Documento CONFIDENCIAL gerado automaticamente pela plataforma · www.dtfinance.com.br",
      W / 2, 291, { align: "center" }
    );
    doc.setTextColor(80, 110, 150);
    doc.text(`Pág. ${p} / ${totalPages}`, W - 14, 291, { align: "right" });
  }

  /* ── Download ── */
  doc.save(`DT Finance — ${reportTitles[type]} ${periodo}.pdf`);
}
