const SESSION_KEY = "dtf_auth";

const CREDENTIALS = {
  user: "dtfinance",
  pass: "kankaslilas",
};

export function login(user: string, pass: string): boolean {
  if (user === CREDENTIALS.user && pass === CREDENTIALS.pass) {
    sessionStorage.setItem(SESSION_KEY, "1");
    return true;
  }
  return false;
}

export function logout(): void {
  sessionStorage.removeItem(SESSION_KEY);
}

export function isAuthenticated(): boolean {
  return sessionStorage.getItem(SESSION_KEY) === "1";
}
