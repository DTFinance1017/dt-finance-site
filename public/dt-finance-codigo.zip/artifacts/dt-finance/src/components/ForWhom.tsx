import { FadeIn } from "./FadeIn";
import { Building2, TrendingUp, Users, Rocket } from "lucide-react";

const profiles = [
  {
    icon: <Building2 size={22} className="text-[#3b82f6]" />,
    title: "PMEs em crescimento",
    description: "Empresas que faturam entre R$ 3M e R$ 80M e crescem sem estrutura financeira proporcional. O negócio avança; o controle fica para trás.",
    color: "#3b82f6",
    tag: "Perfil mais comum",
  },
  {
    icon: <TrendingUp size={22} className="text-[#10b981]" />,
    title: "Empresas pré-investimento ou captação",
    description: "Precisam apresentar dados financeiros confiáveis para investidores, bancos ou processos de fusão. A desorganização custa oportunidades.",
    color: "#10b981",
    tag: null,
  },
  {
    icon: <Users size={22} className="text-[#f0c040]" />,
    title: "Grupos com múltiplas unidades",
    description: "Holdings, redes e grupos empresariais que precisam consolidar resultados de diferentes CNPJs em uma visão única e gerencial.",
    color: "#f0c040",
    tag: null,
  },
  {
    icon: <Rocket size={22} className="text-[#0d9488]" />,
    title: "Startups e scale-ups em expansão",
    description: "Em fase de escala, precisam de CFO estratégico sem o custo e rigidez de um executivo sênior fixo. Estrutura sob medida para cada fase.",
    color: "#0d9488",
    tag: null,
  },
];

export function ForWhom() {
  return (
    <section id="para-quem" className="py-24 bg-[#040c1c] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <FadeIn className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#f0c040]/30 bg-[#f0c040]/10 text-[#f0c040] text-xs font-medium mb-4">
            PARA QUEM É
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl sm:text-4xl md:text-5xl font-bold text-white">
            Se a empresa cresce mas o
            <br />
            <span className="gradient-text">controle não acompanha</span>
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto">
            Estágios diferentes, mesmo problema: falta de clareza financeira para decidir com segurança.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {profiles.map((p, i) => (
            <FadeIn key={i} delay={i * 80}>
              <div
                className="relative flex gap-5 p-6 rounded-2xl border border-white/7 bg-[#060d1e] group cursor-default"
                style={{ transition: "all 0.3s ease" }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = `${p.color}35`;
                  e.currentTarget.style.transform = "translateY(-2px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)";
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                {p.tag && (
                  <div
                    className="absolute top-4 right-4 text-[9px] px-2 py-1 rounded-full font-medium"
                    style={{ background: `${p.color}18`, color: p.color }}
                  >
                    {p.tag}
                  </div>
                )}
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${p.color}15` }}>
                  {p.icon}
                </div>
                <div>
                  <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="text-base font-semibold text-white mb-2">{p.title}</h3>
                  <p className="text-sm text-white/50 leading-relaxed">{p.description}</p>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
