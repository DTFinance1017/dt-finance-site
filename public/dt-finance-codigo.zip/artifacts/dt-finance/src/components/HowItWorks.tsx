import { FadeIn } from "./FadeIn";
import { Upload, ScanLine, Bot, LayoutDashboard, Lightbulb, CheckCircle2 } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: <Upload size={20} className="text-[#3b82f6]" />,
    title: "Você envia os dados",
    description: "Extratos bancários, contas a pagar e receber, faturas, relatórios do contador. Pelo portal, simples e seguro.",
    color: "#3b82f6",
  },
  {
    number: "02",
    icon: <ScanLine size={20} className="text-[#0ea5e9]" />,
    title: "O sistema organiza",
    description: "Leitura automática, categorização e estruturação dos dados em padrões financeiros gerenciais. Sem trabalho manual da sua parte.",
    color: "#0ea5e9",
  },
  {
    number: "03",
    icon: <Bot size={20} className="text-[#0d9488]" />,
    title: "O agente interno estrutura",
    description: "Nosso agente classifica transações, concilia informações e prepara a base analítica com integridade e consistência.",
    color: "#0d9488",
  },
  {
    number: "04",
    icon: <LayoutDashboard size={20} className="text-[#d97706]" />,
    title: "Os indicadores são gerados",
    description: "DRE gerencial, fluxo de caixa, margens, KPIs e alertas — tudo calculado e apresentado de forma visual e clara.",
    color: "#d97706",
  },
  {
    number: "05",
    icon: <Lightbulb size={20} className="text-[#f0c040]" />,
    title: "A DT Finance analisa",
    description: "Nossa equipe interpreta os dados, identifica riscos e oportunidades, e orienta sua próxima decisão com base sólida.",
    color: "#f0c040",
  },
  {
    number: "06",
    icon: <CheckCircle2 size={20} className="text-[#10b981]" />,
    title: "Você decide com clareza",
    description: "Relatório executivo em mãos. Informação clara, linguagem direta, pronta para a reunião de diretoria ou para a sua mesa.",
    color: "#10b981",
  },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="py-24 bg-[#040c1c] relative overflow-hidden">
      <div className="absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#1e40af]/30 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <FadeIn className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#10b981]/30 bg-[#10b981]/10 text-[#10b981] text-xs font-medium mb-4">
            COMO FUNCIONA
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif" }} className="text-3xl sm:text-4xl md:text-5xl font-bold text-white">
            Você envia os dados.
            <br />
            <span className="gradient-text">Nós entregamos a clareza.</span>
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto">
            Um processo estruturado que combina tecnologia e inteligência financeira — sem sobrecarregar sua equipe interna.
          </p>
        </FadeIn>

        {/* Flow arrow visual */}
        <FadeIn>
          <div className="flex items-center justify-center gap-2 mb-10 overflow-x-auto pb-2">
            {["Dados", "→", "Organização", "→", "Análise", "→", "Clareza"].map((item, i) => (
              <span
                key={i}
                className={`text-xs font-medium px-3 py-1.5 rounded-full flex-shrink-0 ${
                  item === "→"
                    ? "text-white/20"
                    : i === 6
                    ? "bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/25"
                    : "bg-white/5 text-white/40 border border-white/8"
                }`}
              >
                {item}
              </span>
            ))}
          </div>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {steps.map((step, i) => (
            <FadeIn key={i} delay={i * 80}>
              <div className="relative flex flex-col p-6 rounded-2xl border border-white/7 bg-[#060d1e] h-full group hover:border-white/15 transition-all duration-300">
                <div className="step-number mb-4">{step.number}</div>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-5" style={{ background: `${step.color}15` }}>
                  {step.icon}
                </div>
                <h3 style={{ fontFamily: "'Playfair Display', serif" }} className="text-base font-semibold text-white mb-2">{step.title}</h3>
                <p className="text-sm text-white/55 leading-relaxed">{step.description}</p>
                <div
                  className="absolute bottom-0 left-6 right-6 h-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ background: `linear-gradient(90deg, transparent, ${step.color}, transparent)` }}
                />
              </div>
            </FadeIn>
          ))}
        </div>

        {/* Bottom tag */}
        <FadeIn delay={400}>
          <div className="mt-10 text-center">
            <span
              className="inline-flex items-center gap-2 text-xs text-white/40 px-5 py-2.5 rounded-full border border-white/8"
              style={{ background: "rgba(255,255,255,0.02)" }}
            >
              Não é software puro. É inteligência financeira aplicada ao seu negócio.
            </span>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
