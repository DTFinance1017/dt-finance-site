import { Award, Briefcase, Scale, TrendingUp } from "lucide-react";

export function QuemSomos() {
  const socios = [
    {
      avatar: "CFP",
      gradientFrom: "#1e40af",
      gradientTo: "#0ea5e9",
      accentColor: "#0ea5e9",
      titulo: "Especialista em Gestão Financeira",
      certificacao: "CFP® — Certified Financial Planner",
      descricao:
        "Profissional com mais de 15 anos de experiência no mercado financeiro, com foco em gestão financeira empresarial, planejamento de investimentos e inteligência comercial. Ao longo da carreira, apoiou empresas de diferentes setores na estruturação de suas finanças, tornando dados complexos em decisões estratégicas claras.",
      tags: [
        { icon: <TrendingUp size={13} />, label: "Investimentos" },
        { icon: <Briefcase size={13} />, label: "Gestão Financeira" },
        { icon: <Award size={13} />, label: "CFP® Certificado" },
      ],
    },
    {
      avatar: "ADV",
      gradientFrom: "#065f46",
      gradientTo: "#10b981",
      accentColor: "#10b981",
      titulo: "Especialista Jurídico-Empresarial",
      certificacao: "Advogado — OAB",
      descricao:
        "Advogado com mais de 15 anos de atuação junto a pequenas, médias e grandes empresas. Combina o rigor jurídico com profundo entendimento do ambiente de negócios, apoiando clientes em estruturação societária, contratos, conformidade e na interface entre as obrigações legais e a saúde financeira das empresas.",
      tags: [
        { icon: <Scale size={13} />, label: "Direito Empresarial" },
        { icon: <Briefcase size={13} />, label: "PME & Grandes Empresas" },
        { icon: <Award size={13} />, label: "OAB" },
      ],
    },
  ];

  return (
    <section id="quem-somos" className="py-24 bg-[#040c1c] relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 50% at 50% 50%, rgba(30,64,175,0.07) 0%, transparent 70%)",
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#f0c040]/20 bg-[#f0c040]/5 mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#f0c040]" />
            <span className="text-xs font-medium text-[#f0c040]/80 uppercase tracking-widest">
              Nossa Equipe
            </span>
          </div>
          <h2
            style={{ fontFamily: "'Playfair Display', serif" }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-5"
          >
            Quem está por trás da{" "}
            <span className="gradient-text">DT Finance</span>
          </h2>
          <p className="text-white/55 max-w-2xl mx-auto text-base sm:text-lg leading-relaxed">
            Uma sociedade construída sobre mais de 15 anos de experiência real no mercado financeiro e jurídico — unindo dados, estratégia e segurança para o seu negócio.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {socios.map((socio, i) => (
            <div
              key={i}
              className="relative rounded-2xl border border-white/8 bg-white/3 backdrop-blur-sm p-8 flex flex-col gap-6 hover:border-white/15 transition-colors duration-300 group"
            >
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                style={{
                  background: `radial-gradient(ellipse 60% 50% at 30% 30%, ${socio.accentColor}08 0%, transparent 70%)`,
                }}
              />

              <div className="flex items-start gap-5">
                <div
                  className="flex-shrink-0 w-16 h-16 rounded-2xl flex items-center justify-center text-white font-bold text-lg tracking-wide"
                  style={{
                    background: `linear-gradient(135deg, ${socio.gradientFrom}, ${socio.gradientTo})`,
                    boxShadow: `0 8px 24px ${socio.accentColor}30`,
                  }}
                >
                  {socio.avatar}
                </div>
                <div>
                  <h3
                    style={{ fontFamily: "'Playfair Display', serif" }}
                    className="text-white font-semibold text-lg leading-snug mb-1"
                  >
                    {socio.titulo}
                  </h3>
                  <span
                    className="text-xs font-medium px-2.5 py-1 rounded-full"
                    style={{
                      color: socio.accentColor,
                      background: `${socio.accentColor}15`,
                      border: `1px solid ${socio.accentColor}25`,
                    }}
                  >
                    {socio.certificacao}
                  </span>
                </div>
              </div>

              <p className="text-white/55 text-sm leading-relaxed">
                {socio.descricao}
              </p>

              <div className="flex flex-wrap gap-2 mt-auto">
                {socio.tags.map((tag, j) => (
                  <span
                    key={j}
                    className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-white/8 bg-white/4 text-white/60"
                  >
                    <span style={{ color: socio.accentColor }}>{tag.icon}</span>
                    {tag.label}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-14 max-w-3xl mx-auto">
          <div className="rounded-2xl border border-[#f0c040]/15 bg-[#f0c040]/4 p-7 text-center">
            <p
              style={{ fontFamily: "'Playfair Display', serif" }}
              className="text-white/85 text-lg leading-relaxed italic"
            >
              "Unimos direito, tecnologia e finanças para entregar algo que o mercado ainda não tinha: um CFO completo, acessível e orientado a dados."
            </p>
            <span className="mt-4 inline-block text-[#f0c040]/60 text-sm font-medium">
              — Fundadores da DT Finance
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
