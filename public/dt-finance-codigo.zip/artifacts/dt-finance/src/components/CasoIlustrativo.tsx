import { FadeIn } from "./FadeIn";
import { ArrowRight, AlertTriangle, TrendingUp, Eye } from "lucide-react";

export function CasoIlustrativo() {
  return (
    <section className="py-24 bg-[#040c1c] relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(30,64,175,0.07) 0%, transparent 70%)" }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <FadeIn className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#0d9488]/30 bg-[#0d9488]/10 text-[#2dd4bf] text-xs font-medium mb-4">
            CASO ILUSTRATIVO
          </div>
          <h2
            style={{ fontFamily: "'Playfair Display', serif" }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white"
          >
            Como uma empresa saiu do
            <br />
            <span className="gradient-text">achismo para a clareza</span>
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto">
            Um exemplo representativo do perfil de empresas que atendemos — com números simulados para fins ilustrativos.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Situação Inicial */}
          <FadeIn>
            <div
              className="rounded-2xl border p-6 h-full"
              style={{ borderColor: "rgba(239,68,68,0.18)", background: "#0a0608" }}
            >
              <div className="flex items-center gap-2 mb-5">
                <AlertTriangle size={16} className="text-red-400" />
                <span className="text-xs font-semibold text-red-400 uppercase tracking-wider">Situação Inicial</span>
              </div>

              <div
                style={{ fontFamily: "'Playfair Display', serif" }}
                className="text-base font-semibold text-white mb-4"
              >
                Empresa de serviços. R$ 8M de faturamento anual.
              </div>

              <div className="space-y-3">
                {[
                  "Crescimento de 40% no ano — caixa não acompanhou",
                  "DRE feita pelo contador, sem visão gerencial",
                  "Dois sócios com retiradas sem critério definido",
                  "Inadimplência desconhecida — estimavam 2%, era 7%",
                  "Decisão de abrir nova unidade baseada em \"feeling\"",
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-2 flex-shrink-0" />
                    <p className="text-xs text-white/55 leading-relaxed">{item}</p>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>

          {/* O que a DT Finance fez */}
          <FadeIn delay={100}>
            <div
              className="rounded-2xl border p-6 h-full"
              style={{ borderColor: "rgba(59,130,246,0.25)", background: "#060a14" }}
            >
              <div className="flex items-center gap-2 mb-5">
                <ArrowRight size={16} className="text-blue-400" />
                <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">O que estruturamos</span>
              </div>

              <div
                style={{ fontFamily: "'Playfair Display', serif" }}
                className="text-base font-semibold text-white mb-4"
              >
                Implantação em 45 dias
              </div>

              <div className="space-y-3">
                {[
                  "Separação completa de pessoa física e jurídica",
                  "DRE gerencial por linha de serviço e por sócio",
                  "Fluxo de caixa projetado para 90 dias",
                  "Dashboard executivo mensal automatizado",
                  "Política de retirada de pró-labore definida com base em margem",
                  "Alerta de inadimplência com aging de recebíveis",
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-2 flex-shrink-0" />
                    <p className="text-xs text-white/65 leading-relaxed">{item}</p>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>

          {/* Resultado */}
          <FadeIn delay={200}>
            <div
              className="rounded-2xl border p-6 h-full"
              style={{ borderColor: "rgba(16,185,129,0.25)", background: "#06100d" }}
            >
              <div className="flex items-center gap-2 mb-5">
                <TrendingUp size={16} className="text-emerald-400" />
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Resultado Gerado</span>
              </div>

              <div
                style={{ fontFamily: "'Playfair Display', serif" }}
                className="text-base font-semibold text-white mb-4"
              >
                Dentro dos primeiros 90 dias
              </div>

              <div className="space-y-4">
                {[
                  { metric: "Inadimplência real identificada", value: "7%", detail: "vs. 2% que achavam" },
                  { metric: "Economia identificada em custos", value: "R$ 140K/ano", detail: "sem cortar equipe" },
                  { metric: "Margem líquida real apurada", value: "18,3%", detail: "antes era estimada em 25%" },
                  { metric: "Decisão de nova unidade", value: "Adiada", detail: "caixa não comportava no prazo" },
                ].map((item, i) => (
                  <div key={i} className="p-3 rounded-xl" style={{ background: "rgba(16,185,129,0.07)", border: "1px solid rgba(16,185,129,0.12)" }}>
                    <div className="text-[10px] text-emerald-400/70 uppercase tracking-wide mb-1">{item.metric}</div>
                    <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-lg font-bold text-emerald-400">{item.value}</div>
                    <div className="text-[10px] text-white/40">{item.detail}</div>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex items-center gap-2 text-xs text-white/35">
                <Eye size={11} />
                <span>Dados ilustrativos. Resultado real varia por empresa.</span>
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
