import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { useLocation } from "wouter";
import { ContatoModal } from "./ContatoModal";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [, navigate] = useLocation();
  const [location] = useLocation();

  const isHome = location === "/";

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    if (isHome) {
      const el = document.querySelector(id);
      if (el) el.scrollIntoView({ behavior: "smooth" });
    } else {
      navigate("/");
      setTimeout(() => {
        const el = document.querySelector(id);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }, 400);
    }
  };

  const links = [
    { label: "Soluções", action: () => scrollTo("#solucoes") },
    { label: "Como Funciona", action: () => scrollTo("#como-funciona") },
    { label: "Plataforma", action: () => { setMobileOpen(false); navigate("/plataforma"); } },
    { label: "Diferenciais", action: () => scrollTo("#diferenciais") },
    { label: "Quem Somos", action: () => scrollTo("#quem-somos") },
  ];

  return (
    <>
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled || !isHome
          ? "bg-[#040c1c]/92 backdrop-blur-md border-b border-white/5 shadow-lg"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => { navigate("/"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
          >
            <img
              src="/logo-dt-v2.png"
              alt="DT Finance"
              className="h-9 w-auto object-contain"
            />
            <span style={{ fontFamily: "'Playfair Display', serif" }} className="text-white font-semibold text-lg tracking-tight">
              DT Finance
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <button key={link.label} onClick={link.action} className="text-sm text-white/70 hover:text-white transition-colors duration-200 font-medium">
                {link.label}
              </button>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => navigate("/login")}
              className="btn-outline-blue px-4 py-2.5 rounded-lg text-sm font-medium"
            >
              Área do Cliente
            </button>
            <button
              onClick={() => setModalOpen(true)}
              className="btn-gold px-5 py-2.5 rounded-lg text-sm font-semibold"
            >
              Falar com a DT Finance
            </button>
          </div>

          <button className="md:hidden text-white/80 hover:text-white p-2" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-[#040c1c]/95 backdrop-blur-md border-t border-white/5">
          <div className="px-4 py-4 space-y-3">
            {links.map((link) => (
              <button key={link.label} onClick={link.action} className="block w-full text-left text-white/80 hover:text-white py-2 text-sm font-medium transition-colors">
                {link.label}
              </button>
            ))}
            <button onClick={() => { setMobileOpen(false); navigate("/login"); }} className="block w-full text-left text-white/80 hover:text-white py-2 text-sm font-medium transition-colors">
              Área do Cliente
            </button>
            <button onClick={() => { setMobileOpen(false); setModalOpen(true); }} className="btn-gold w-full px-5 py-3 rounded-lg text-sm font-semibold mt-2">
              Falar com a DT Finance
            </button>
          </div>
        </div>
      )}
    </nav>

    <ContatoModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
}
