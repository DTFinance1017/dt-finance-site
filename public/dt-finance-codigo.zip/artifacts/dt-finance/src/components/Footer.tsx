export function Footer() {
  return (
    <footer className="border-t border-white/8 bg-[#030a18] py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div
              className="flex items-center gap-3 mb-4 cursor-pointer"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            >
              <img
                src="/logo-dt-v2.png"
                alt="DT Finance"
                className="h-10 w-auto object-contain"
              />
              <span
                style={{ fontFamily: "'Playfair Display', serif" }}
                className="text-white font-semibold text-lg"
              >
                DT Finance
              </span>
            </div>
            <p className="text-sm text-white/40 max-w-xs leading-relaxed">
              Inteligência financeira baseada em dados para empresas que precisam de clareza, não apenas de números.
            </p>
          </div>

          {/* Soluções */}
          <div>
            <div className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-5">
              Soluções
            </div>
            <ul className="space-y-3">
              {[
                "Dashboards Gerenciais",
                "Relatórios Executivos",
                "CFO as a Service",
                "Análise de Fluxo de Caixa",
                "Controladoria Gerencial",
                "Inteligência de Dados",
              ].map((item) => (
                <li key={item}>
                  <a
                    href="#solucoes"
                    onClick={(e) => {
                      e.preventDefault();
                      document.querySelector("#solucoes")?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="text-sm text-white/45 hover:text-white/80 transition-colors duration-200"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contato */}
          <div>
            <div className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-5">
              Contato
            </div>
            <ul className="space-y-3">
              <li>
                <a
                  href="mailto:contato@dtfinance.com.br"
                  className="text-sm text-white/45 hover:text-white/80 transition-colors duration-200"
                >
                  contato@dtfinance.com.br
                </a>
              </li>
              <li>
                <a
                  href="tel:+5511900000000"
                  className="text-sm text-white/45 hover:text-white/80 transition-colors duration-200"
                >
                  +55 (11) 9 0000-0000
                </a>
              </li>
              <li className="text-sm text-white/45">São Paulo, SP</li>
            </ul>

            <div className="mt-8">
              <button
                className="btn-gold px-5 py-2.5 rounded-lg text-sm font-semibold"
                onClick={() => {
                  document.querySelector("#cta")?.scrollIntoView({ behavior: "smooth" });
                }}
              >
                Falar Conosco →
              </button>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/25">
            © 2026 DT Finance. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#10b981] animate-pulse-dot" />
            <span className="text-xs text-white/25">Sistema operacional</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
