import { useState } from "react";
import { X, MessageCircle } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
}

const cargos = [
  "CEO / Diretor Geral",
  "CFO / Diretor Financeiro",
  "Controller",
  "Gerente Financeiro",
  "Contador",
  "Sócio / Proprietário",
  "Outro",
];

const setores = [
  "Agronegócio",
  "Comércio / Varejo",
  "Construção Civil",
  "Educação",
  "Indústria",
  "Saúde",
  "Serviços",
  "Tecnologia",
  "Transporte / Logística",
  "Outro",
];

const erps = [
  "Não utilizo ERP",
  "Conta Azul",
  "Bling",
  "TOTVS / Protheus",
  "SAP",
  "Oracle",
  "Omie",
  "Sankhya",
  "Senior",
  "Outro",
];

const faturamentos = [
  "Até R$ 100 mil/mês",
  "R$ 100 mil – R$ 500 mil/mês",
  "R$ 500 mil – R$ 2 milhões/mês",
  "R$ 2 milhões – R$ 10 milhões/mês",
  "Acima de R$ 10 milhões/mês",
];

const inputClass =
  "w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#3b82f6]/60 focus:bg-white/8 transition-colors";

const selectClass =
  "w-full bg-[#07112a] border border-white/10 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-[#3b82f6]/60 transition-colors appearance-none cursor-pointer";

export function ContatoModal({ open, onClose }: Props) {
  const [form, setForm] = useState({
    nome: "",
    whatsapp: "",
    email: "",
    empresa: "",
    cargo: "",
    setor: "",
    erp: "",
    faturamento: "",
    lgpd: false,
  });
  const [enviado, setEnviado] = useState(false);

  if (!open) return null;

  const set = (field: string, value: string | boolean) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const handleEnviar = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.lgpd) return;

    const msg = [
      `*Novo Diagnóstico Gratuito — DT Finance*`,
      ``,
      `*Nome:* ${form.nome}`,
      `*WhatsApp:* +55 ${form.whatsapp}`,
      `*E-mail:* ${form.email}`,
      `*Empresa:* ${form.empresa || "—"}`,
      `*Cargo:* ${form.cargo}`,
      `*Setor:* ${form.setor}`,
      `*ERP:* ${form.erp}`,
      `*Faturamento mensal:* ${form.faturamento}`,
    ].join("\n");

    const url = `https://wa.me/5511999999999?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
    setEnviado(true);
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{ background: "rgba(4,12,28,0.85)", backdropFilter: "blur(8px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 shadow-2xl"
        style={{
          background: "linear-gradient(160deg, #07112a 0%, #040c1c 100%)",
          boxShadow: "0 32px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(240,192,64,0.06)",
        }}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-8 h-8 flex items-center justify-center rounded-full bg-white/8 hover:bg-white/15 text-white/60 hover:text-white transition-colors"
        >
          <X size={16} />
        </button>

        {enviado ? (
          <div className="flex flex-col items-center justify-center py-20 px-10 text-center">
            <div className="w-16 h-16 rounded-full bg-[#10b981]/15 border border-[#10b981]/30 flex items-center justify-center mb-6">
              <MessageCircle size={28} className="text-[#10b981]" />
            </div>
            <h3
              style={{ fontFamily: "'Playfair Display', serif" }}
              className="text-2xl font-bold text-white mb-3"
            >
              Mensagem enviada!
            </h3>
            <p className="text-white/55 mb-8 text-sm leading-relaxed max-w-sm">
              Sua solicitação foi encaminhada via WhatsApp. Nossa equipe retornará em até 24 horas úteis.
            </p>
            <button onClick={onClose} className="btn-gold px-8 py-3 rounded-xl text-sm font-semibold">
              Fechar
            </button>
          </div>
        ) : (
          <form onSubmit={handleEnviar} className="p-7 sm:p-9">
            <div className="mb-7">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#f0c040]/25 bg-[#f0c040]/8 text-[#f0c040] text-xs font-medium mb-4">
                DIAGNÓSTICO GRATUITO
              </div>
              <h2
                style={{ fontFamily: "'Playfair Display', serif" }}
                className="text-2xl sm:text-3xl font-bold text-white mb-2"
              >
                Fale com um especialista.
              </h2>
              <p className="text-white/45 text-sm">
                Preencha o formulário e nossa equipe entrará em contato pelo WhatsApp.
              </p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">Nome*</label>
                  <input
                    required
                    className={inputClass}
                    placeholder="Nome e sobrenome"
                    value={form.nome}
                    onChange={(e) => set("nome", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">WhatsApp*</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-sm text-white/60 pointer-events-none">
                      🇧🇷 +55
                    </span>
                    <input
                      required
                      className={`${inputClass} pl-20`}
                      placeholder="(DDD) 99999-9999"
                      value={form.whatsapp}
                      onChange={(e) => set("whatsapp", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">E-mail*</label>
                  <input
                    required
                    type="email"
                    className={inputClass}
                    placeholder="nome@empresa.com.br"
                    value={form.email}
                    onChange={(e) => set("email", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">Nome da Empresa</label>
                  <input
                    className={inputClass}
                    placeholder="Nome da Empresa"
                    value={form.empresa}
                    onChange={(e) => set("empresa", e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">Cargo*</label>
                  <div className="relative">
                    <select
                      required
                      className={selectClass}
                      value={form.cargo}
                      onChange={(e) => set("cargo", e.target.value)}
                    >
                      <option value="" disabled>Selecione</option>
                      {cargos.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none">▾</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">Setor*</label>
                  <div className="relative">
                    <select
                      required
                      className={selectClass}
                      value={form.setor}
                      onChange={(e) => set("setor", e.target.value)}
                    >
                      <option value="" disabled>Selecione</option>
                      {setores.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none">▾</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">Qual ERP sua empresa utiliza?*</label>
                  <div className="relative">
                    <select
                      required
                      className={selectClass}
                      value={form.erp}
                      onChange={(e) => set("erp", e.target.value)}
                    >
                      <option value="" disabled>Selecione</option>
                      {erps.map((r) => <option key={r} value={r}>{r}</option>)}
                    </select>
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none">▾</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-white/50 mb-1.5 font-medium">Faixa de faturamento mensal*</label>
                  <div className="relative">
                    <select
                      required
                      className={selectClass}
                      value={form.faturamento}
                      onChange={(e) => set("faturamento", e.target.value)}
                    >
                      <option value="" disabled>Selecione</option>
                      {faturamentos.map((f) => <option key={f} value={f}>{f}</option>)}
                    </select>
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none">▾</span>
                  </div>
                </div>
              </div>

              <label className="flex items-start gap-3 cursor-pointer group mt-2">
                <div className="relative mt-0.5">
                  <input
                    type="checkbox"
                    className="sr-only"
                    checked={form.lgpd}
                    onChange={(e) => set("lgpd", e.target.checked)}
                  />
                  <div
                    className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                      form.lgpd
                        ? "bg-[#10b981] border-[#10b981]"
                        : "border-white/20 bg-white/5 group-hover:border-white/40"
                    }`}
                  >
                    {form.lgpd && (
                      <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 10 8">
                        <path d="M1 4l3 3 5-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                  </div>
                </div>
                <span className="text-xs text-white/40 leading-relaxed">
                  Concordo em receber propostas, informações e atendimento comercial da DT Finance pelo WhatsApp.
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={!form.lgpd}
              className="mt-7 w-full btn-gold py-4 rounded-xl text-sm font-bold tracking-wide flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <MessageCircle size={16} />
              ENVIAR
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
