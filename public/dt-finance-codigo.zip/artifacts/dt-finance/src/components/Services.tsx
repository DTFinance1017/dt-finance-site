import { FadeIn } from "./FadeIn";

const services = [
  {
    icon: "◈",
    title: "Dashboards Gerenciais",
    description: "Seus dados financeiros transformados em painel executivo. Margens, caixa, inadimplência e resultado — numa tela, toda semana.",
    color: "#3b82f6",
    glow: "rgba(59,130,246,0.15)",
    border: "rgba(59,130,246,0.3)",
  },
  {
    icon: "◉",
    title: "Relatórios Executivos",
    description: "Todo início de mês: DRE gerencial, fluxo de caixa, KPIs e alertas. Pronto para apresentar ao board, sócios ou investidores.",
    color: "#f0c040",
    glow: "rgba(240,192,64,0.12)",
    border: "rgba(240,192,64,0.3)",
  },
  {
    icon: "◎",
    title: "CFO as a Service",
    description: "Diretoria financeira estratégica sem o custo de executivo fixo. Planejamento, estruturação e suporte de alto nível quando você precisa.",
    color: "#10b981",
    glow: "rgba(16,185,129,0.12)",
    border: "rgba(16,185,129,0.3)",
  },
  {
    icon: "⬡",
    title: "Fluxo de Caixa Projetado",
    description: "Projeções de 30, 60 e 90 dias. Identifique gargalos antes que apareçam e gerencie capital de giro com segurança.",
    color: "#0ea5e9",
    glow: "rgba(14,165,233,0.12)",
    border: "rgba(14,165,233,0.3)",
  },
  {
    icon: "⬟",
    title: "Controladoria Gerencial",
    description: "Plano de contas gerencial, DRE por produto ou unidade, centros de custo e margens reais — separados do contábil.",
    color: "#0d9488",
    glow: "rgba(13,148,136,0.12)",
    border: "rgba(13,148,136,0.3)",
  },
  {
    icon: "◇",
    title: "Inteligência de Dados",
    description: "Consolidação de fontes dispersas, automação de processos manuais e modelos analíticos para decisões com base sólida.",
    color: "#d97706",
    glow: "rgba(217,119,6,0.12)",
    border: "rgba(217,119,6,0.3)",
  },
];

export function Services() {
  return (
    <section id="solucoes" className="py-24 bg-[#040c1c] relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#0a1628]/50 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <FadeIn className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#3b82f6]/30 bg-[#3b82f6]/10 text-[#60a5fa] text-xs font-medium mb-4">
            SOLUÇÕES
          </div>
          <h2
            style={{ fontFamily: "'Playfair Display', serif" }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white"
          >
            Tudo que sua empresa precisa
            <br />
            <span className="gradient-text">para ter clareza financeira real</span>
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto">
            Do dado bruto ao relatório estratégico. Cada entrega tem propósito claro e impacto direto na sua gestão.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <FadeIn key={i} delay={i * 80}>
              <div
                className="service-card group h-full p-6 rounded-2xl border bg-[#060d1e] cursor-default"
                style={{ borderColor: "rgba(255,255,255,0.07)", transition: "all 0.3s ease" }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget;
                  el.style.borderColor = service.border;
                  el.style.boxShadow = `0 8px 32px ${service.glow}, inset 0 0 24px ${service.glow}`;
                  el.style.transform = "translateY(-4px)";
                  el.style.background = `linear-gradient(135deg, #060d1e, #080f22)`;
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget;
                  el.style.borderColor = "rgba(255,255,255,0.07)";
                  el.style.boxShadow = "none";
                  el.style.transform = "translateY(0)";
                  el.style.background = "#060d1e";
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-xl mb-5"
                  style={{ background: `${service.color}18`, color: service.color }}
                >
                  {service.icon}
                </div>
                <h3
                  style={{ fontFamily: "'Playfair Display', serif" }}
                  className="text-lg font-semibold text-white mb-3"
                >
                  {service.title}
                </h3>
                <p className="text-sm text-white/55 leading-relaxed">{service.description}</p>

                <div
                  className="mt-5 text-xs font-medium flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                  style={{ color: service.color }}
                >
                  Saiba mais <span>→</span>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
