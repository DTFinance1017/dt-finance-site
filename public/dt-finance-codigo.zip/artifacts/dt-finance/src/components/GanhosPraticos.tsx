import { FadeIn } from "./FadeIn";
import { DollarSign, Eye, Calendar, Search, ShieldCheck, BarChart3 } from "lucide-react";

const ganhos = [
  {
    icon: <DollarSign size={22} />,
    title: "Clareza sobre o lucro real",
    description: "Você saberá exatamente quanto sobra do seu faturamento depois de pagar tudo — com margem por produto, serviço ou unidade.",
    color: "#10b981",
    highlight: true,
  },
  {
    icon: <Calendar size={22} />,
    title: "Controle de caixa com visão de futuro",
    description: "Projeção de 30, 60 e 90 dias à frente. Saber o que vem te permite planejar — em vez de reagir quando já é tarde.",
    color: "#3b82f6",
    highlight: false,
  },
  {
    icon: <Eye size={22} />,
    title: "Visão mensal estruturada",
    description: "Todo início de mês, um relatório executivo pronto: DRE, fluxo de caixa, KPIs e alertas. Sem precisar montar nada.",
    color: "#f0c040",
    highlight: false,
  },
  {
    icon: <Search size={22} />,
    title: "Identificação de gargalos",
    description: "Descubra onde o dinheiro está sendo consumido sem retorno — despesas desnecessárias, inadimplência oculta, custos fora de controle.",
    color: "#0d9488",
    highlight: false,
  },
  {
    icon: <ShieldCheck size={22} />,
    title: "Redução de riscos financeiros",
    description: "Alertas automáticos antes que o problema apareça. Concentração de cliente, queda de margem, pressão de caixa — você sabe antes.",
    color: "#0ea5e9",
    highlight: false,
  },
  {
    icon: <BarChart3 size={22} />,
    title: "Decisões baseadas em dados reais",
    description: "Contratar, investir, expandir ou recuar — cada decisão apoiada em números reais, não em sensação. Isso vale mais do que qualquer consultoria genérica.",
    color: "#d97706",
    highlight: false,
  },
];

export function GanhosPraticos() {
  return (
    <section className="py-24 bg-[#040c1c] relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 70% 50% at 50% 50%, rgba(16,185,129,0.05) 0%, transparent 70%)" }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <FadeIn className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#10b981]/30 bg-[#10b981]/10 text-[#34d399] text-xs font-medium mb-4">
            O QUE VOCÊ GANHA NA PRÁTICA
          </div>
          <h2
            style={{ fontFamily: "'Playfair Display', serif" }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white"
          >
            Resultado concreto,
            <br />
            <span className="gradient-text">não promessa vaga</span>
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto text-lg">
            Tudo o que entregamos tem nome, data e impacto mensurável na operação da sua empresa.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {ganhos.map((g, i) => (
            <FadeIn key={i} delay={i * 70}>
              <div
                className="p-6 rounded-2xl border h-full group cursor-default transition-all duration-300"
                style={{
                  borderColor: g.highlight ? `${g.color}35` : "rgba(255,255,255,0.07)",
                  background: g.highlight ? `linear-gradient(135deg, #060d1e, #07120e)` : "#060d1e",
                  boxShadow: g.highlight ? `0 0 30px ${g.color}12` : "none",
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                  style={{ background: `${g.color}18`, color: g.color }}
                >
                  {g.icon}
                </div>
                <h3
                  style={{ fontFamily: "'Playfair Display', serif" }}
                  className="text-base font-semibold text-white mb-3"
                >
                  {g.title}
                </h3>
                <p className="text-sm text-white/55 leading-relaxed">{g.description}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
