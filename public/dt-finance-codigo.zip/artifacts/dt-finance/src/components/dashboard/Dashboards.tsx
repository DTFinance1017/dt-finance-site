import { useState } from "react";
import { AnaliseAnual } from "./AnaliseAnual";

const cashFlow = [
  { month: "Abr", in: 72, out: 55, net: 17 }, { month: "Mai", in: 80, out: 62, net: 18 },
  { month: "Jun", in: 68, out: 50, net: 18 }, { month: "Jul", in: 90, out: 71, net: 19 },
  { month: "Ago", in: 85, out: 65, net: 20 }, { month: "Set", in: 95, out: 68, net: 27 },
  { month: "Out", in: 88, out: 72, net: 16 }, { month: "Nov", in: 102, out: 78, net: 24 },
  { month: "Dez", in: 110, out: 82, net: 28 }, { month: "Jan", in: 78, out: 58, net: 20 },
  { month: "Fev", in: 84, out: 62, net: 22 }, { month: "Mar", in: 95, out: 68, net: 27 },
];

const expenses = [
  { label: "Pessoal & RH", pct: 38, color: "#3b82f6" },
  { label: "Custo de Mercadoria", pct: 24, color: "#10b981" },
  { label: "Financeiras", pct: 14, color: "#f0c040" },
  { label: "Administrativas", pct: 12, color: "#0d9488" },
  { label: "Marketing", pct: 7, color: "#0ea5e9" },
  { label: "Outras", pct: 5, color: "#d97706" },
];

const clients = [
  { name: "Grupo Alpha", pct: 38, color: "#d97706" },
  { name: "Beta Indústria", pct: 24, color: "#3b82f6" },
  { name: "Gamma Tech", pct: 18, color: "#0d9488" },
  { name: "Delta Serviços", pct: 12, color: "#10b981" },
  { name: "Outros", pct: 8, color: "#6b7280" },
];

const resultEvo = [28, 32, 29, 35, 31, 38, 36, 42, 45, 40, 44, 48];
const months = ["Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez", "Jan", "Fev", "Mar"];

const tabs = ["Fluxo de Caixa", "Composição de Despesas", "Concentração Clientes", "Evolução de Resultado", "Análise Anual 2026"];

export function Dashboards() {
  const [tab, setTab] = useState(0);

  return (
    <div className="space-y-5">
      {/* Tab bar */}
      <div className="flex gap-1 p-1 rounded-xl border border-white/7 bg-[#060d1e] overflow-x-auto">
        {tabs.map((t, i) => (
          <button
            key={i}
            onClick={() => setTab(i)}
            className={`whitespace-nowrap px-4 py-2 rounded-lg text-xs font-medium transition-all flex-shrink-0 ${tab === i ? "bg-[#1e40af]/35 text-[#60a5fa]" : "text-white/40 hover:text-white/70"}`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Dashboard content */}
      <div className="rounded-xl border border-white/7 bg-[#060d1e] p-5">
        {tab === 0 && (
          <div>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-sm font-semibold text-white">Fluxo de Caixa — 12 meses</h3>
                <p className="text-xs text-white/35 mt-0.5">Abr 2024 – Mar 2025</p>
              </div>
              <div className="flex gap-4 text-xs text-white/40">
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-[#3b82f6]" />Entradas</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-[#d97706]/55" />Saídas</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-[#10b981]" />Resultado</span>
              </div>
            </div>
            <div className="flex items-end gap-2 h-48">
              {cashFlow.map((d, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                  <div className="w-full flex gap-0.5 items-end justify-center h-full">
                    <div className="flex-1 rounded-t-sm bg-[#3b82f6]/65 group-hover:bg-[#3b82f6] transition-colors" style={{ height: `${(d.in / 120) * 100}%` }} />
                    <div className="flex-1 rounded-t-sm bg-[#d97706]/40 group-hover:bg-[#d97706]/60 transition-colors" style={{ height: `${(d.out / 120) * 100}%` }} />
                    <div className="flex-1 rounded-t-sm bg-[#10b981]/70 group-hover:bg-[#10b981] transition-colors" style={{ height: `${(d.net / 120) * 100}%` }} />
                  </div>
                  <div className="text-[9px] text-white/30">{d.month}</div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-3 mt-5 pt-4 border-t border-white/5">
              {[
                { l: "Total Entradas", v: "R$ 1.047K", c: "#3b82f6" },
                { l: "Total Saídas", v: "R$ 793K", c: "#d97706" },
                { l: "Resultado Líquido", v: "+R$ 254K", c: "#10b981" },
              ].map((s, i) => (
                <div key={i} className="text-center">
                  <div className="text-xs text-white/40 mb-1">{s.l}</div>
                  <div style={{ fontFamily: "'Playfair Display', serif", color: s.c }} className="text-lg font-bold">{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 1 && (
          <div>
            <h3 className="text-sm font-semibold text-white mb-5">Composição de Despesas — Mar/25</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
              {/* Donut (CSS) */}
              <div className="relative flex items-center justify-center">
                <div className="w-36 h-36 rounded-full" style={{
                  background: `conic-gradient(#3b82f6 0% 38%, #10b981 38% 62%, #f0c040 62% 76%, #0d9488 76% 88%, #0ea5e9 88% 95%, #d97706 95% 100%)`
                }} />
                <div className="absolute w-24 h-24 rounded-full flex items-center justify-center" style={{ background: "#060d1e" }}>
                  <div className="text-center">
                    <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-white">100%</div>
                    <div className="text-[9px] text-white/40">Total</div>
                  </div>
                </div>
              </div>
              <div className="space-y-2.5">
                {expenses.map((e, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-white/65">{e.label}</span>
                      <span className="font-medium text-white">{e.pct}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/8 overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${e.pct}%`, background: e.color }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 2 && (
          <div>
            <h3 className="text-sm font-semibold text-white mb-1">Concentração de Clientes — Mar/25</h3>
            <p className="text-xs text-white/35 mb-5">% da Receita Bruta por cliente</p>
            <div className="space-y-3">
              {clients.map((c, i) => (
                <div key={i}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-white/70">{c.name}</span>
                    <span className="font-medium text-white">{c.pct}%</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-white/8 overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${c.pct}%`, background: c.color }} />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-5 p-4 rounded-xl border border-[#d97706]/25 bg-[#d97706]/8">
              <div className="text-xs font-medium text-[#d97706] mb-1">⚠ Alerta de Concentração</div>
              <div className="text-xs text-[#d97706]/80 leading-relaxed">Grupo Alpha representa 38% da receita. Alta concentração em único cliente representa risco operacional relevante. Recomenda-se estratégia de diversificação de carteira.</div>
            </div>
          </div>
        )}

        {tab === 4 && <AnaliseAnual />}

        {tab === 3 && (
          <div>
            <h3 className="text-sm font-semibold text-white mb-1">Evolução do Resultado Líquido</h3>
            <p className="text-xs text-white/35 mb-5">em R$ mil · Abr 2024 – Mar 2025</p>
            <div className="flex items-end gap-2 h-44">
              {resultEvo.map((v, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                  <div
                    className="w-full rounded-t-md transition-all duration-700 cursor-default group-hover:opacity-90"
                    style={{
                      height: `${(v / 55) * 100}%`,
                      background: `linear-gradient(to top, #1e40af, #3b82f6)`,
                    }}
                  />
                  <div className="text-[9px] text-white/30">{months[i]}</div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5 text-xs text-white/40">
              <span>Menor: R$ 280K (Abr/24)</span>
              <span>Maior: R$ 480K (Mar/25)</span>
              <span className="text-[#10b981]">Crescimento: +71%</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
