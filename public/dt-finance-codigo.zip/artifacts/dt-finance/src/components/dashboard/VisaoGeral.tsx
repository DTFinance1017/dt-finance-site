import { TrendingUp, TrendingDown, DollarSign, Percent, Landmark, AlertCircle } from "lucide-react";

const kpis = [
  { label: "Receita Bruta", value: "R$ 2,84M", change: "+12,4%", pos: true, icon: <DollarSign size={16} />, color: "#3b82f6" },
  { label: "Margem EBITDA", value: "31,4%", change: "+2,1pp", pos: true, icon: <Percent size={16} />, color: "#10b981" },
  { label: "Lucro Líquido", value: "R$ 412K", change: "+8,3%", pos: true, icon: <TrendingUp size={16} />, color: "#10b981" },
  { label: "Caixa Disponível", value: "R$ 1,12M", change: "-5,2%", pos: false, icon: <Landmark size={16} />, color: "#f0c040" },
  { label: "Endividamento", value: "38,2%", change: "+3,1pp", pos: false, icon: <TrendingDown size={16} />, color: "#d97706" },
  { label: "Liquidez Corrente", value: "1,84", change: "-0,12", pos: false, icon: <AlertCircle size={16} />, color: "#0d9488" },
];

const recentActivity = [
  { label: "Relatório Gerencial Mar/25 gerado", time: "há 2h", color: "#10b981" },
  { label: "Upload de extratos bancários concluído", time: "há 4h", color: "#3b82f6" },
  { label: "Alerta: concentração de cliente acima de 40%", time: "há 1d", color: "#d97706" },
  { label: "DRE Gerencial Fev/25 aprovado", time: "há 3d", color: "#10b981" },
  { label: "Reunião de análise estratégica agendada", time: "há 5d", color: "#0d9488" },
];

const cashFlow = [
  { month: "Out", in: 65, out: 52 }, { month: "Nov", in: 78, out: 60 },
  { month: "Dez", in: 92, out: 71 }, { month: "Jan", in: 71, out: 58 },
  { month: "Fev", in: 80, out: 62 }, { month: "Mar", in: 95, out: 68 },
];

export function VisaoGeral() {
  return (
    <div className="space-y-5">
      {/* KPI grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpis.map((k, i) => (
          <div key={i} className="rounded-xl p-4 border border-white/7 bg-[#060d1e]">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${k.color}18`, color: k.color }}>
                {k.icon}
              </div>
            </div>
            <div className="text-[10px] text-white/40 mb-1">{k.label}</div>
            <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-xl font-bold text-white leading-tight">{k.value}</div>
            <div className={`text-[10px] mt-1.5 font-medium ${k.pos ? "text-[#10b981]" : "text-[#d97706]"}`}>{k.change} vs mês ant.</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Mini chart */}
        <div className="lg:col-span-2 rounded-xl border border-white/7 bg-[#060d1e] p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <div className="text-sm font-semibold text-white">Fluxo de Caixa</div>
              <div className="text-xs text-white/35 mt-0.5">Out 2024 – Mar 2025</div>
            </div>
            <div className="flex gap-4 text-xs text-white/40">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-[#3b82f6]" />Entradas</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm bg-[#d97706]/60" />Saídas</span>
            </div>
          </div>
          <div className="flex items-end gap-3 h-32">
            {cashFlow.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-0.5 h-full justify-end">
                <div className="w-full flex gap-0.5 items-end justify-center h-full">
                  <div className="flex-1 rounded-t-sm bg-[#3b82f6]/70 hover:bg-[#3b82f6] transition-colors" style={{ height: `${(d.in / 100) * 100}%` }} />
                  <div className="flex-1 rounded-t-sm bg-[#d97706]/45 hover:bg-[#d97706]/65 transition-colors" style={{ height: `${(d.out / 100) * 100}%` }} />
                </div>
                <div className="text-[9px] text-white/30 mt-1">{d.month}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent activity */}
        <div className="rounded-xl border border-white/7 bg-[#060d1e] p-5">
          <div className="text-sm font-semibold text-white mb-4">Atividade Recente</div>
          <div className="space-y-3">
            {recentActivity.map((a, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: a.color }} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white/65 leading-snug">{a.label}</p>
                  <p className="text-[10px] text-white/30 mt-0.5">{a.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Status bar */}
      <div className="rounded-xl border border-[#1e40af]/30 bg-[#1e40af]/8 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#3b82f6]/20 flex items-center justify-center">
            <span className="text-[#60a5fa] text-base">🤖</span>
          </div>
          <div>
            <div className="text-sm font-medium text-white">Agente interno ativo</div>
            <div className="text-xs text-white/40">Processamento de Mar/25 em andamento · ETA: 2h</div>
          </div>
        </div>
        <span className="text-[10px] px-3 py-1 rounded-full bg-[#3b82f6]/20 text-[#60a5fa] font-medium">Em processamento</span>
      </div>
    </div>
  );
}
