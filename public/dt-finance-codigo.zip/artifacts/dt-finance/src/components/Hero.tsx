import { useState } from "react";
import { useLocation } from "wouter";
import { ContatoModal } from "./ContatoModal";

export function Hero() {
  const [, navigate] = useLocation();
  const [modalOpen, setModalOpen] = useState(false);

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <section className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-[#040c1c]">
        <div className="absolute inset-0 hero-grid opacity-100" />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 80% 60% at 50% 40%, rgba(30,64,175,0.18) 0%, rgba(14,165,233,0.06) 50%, transparent 70%)" }}
        />
        <div
          className="absolute pointer-events-none"
          style={{ bottom: "-10%", left: "50%", transform: "translateX(-50%)", width: "80%", height: "40%", background: "radial-gradient(ellipse, rgba(240,192,64,0.05) 0%, transparent 70%)" }}
        />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-32 pb-24">
          <div className="max-w-4xl mx-auto text-center">

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#f0c040]/30 bg-[#f0c040]/10 text-[#f0c040] text-xs font-medium mb-8 animate-fade-in">
              CFO AS A SERVICE · CONTROLADORIA GERENCIAL · INTELIGÊNCIA FINANCEIRA
            </div>

            <div className="relative">
              <img
                src="/logo-dt-v2.png"
                alt=""
                aria-hidden="true"
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] max-w-4xl pointer-events-none select-none"
                style={{ opacity: 0.04, filter: "blur(1px)" }}
              />

              <h1
                style={{ fontFamily: "'Playfair Display', serif" }}
                className="relative text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6 animate-fade-in delay-100"
              >
                Sua empresa cresce,
                <br />
                mas os números ainda{" "}
                <span className="gradient-text">não fazem sentido?</span>
              </h1>
            </div>

            <p className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto mb-4 leading-relaxed animate-fade-in delay-200">
              A DT Finance organiza seus dados financeiros, estrutura os indicadores e entrega clareza gerencial para você decidir com segurança — não no achismo.
            </p>

            <p className="text-sm text-white/40 max-w-xl mx-auto mb-10 animate-fade-in delay-200">
              Do extrato bancário ao diagnóstico estratégico. Do dado bruto à decisão consciente.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in delay-300">
              <button
                onClick={() => setModalOpen(true)}
                className="btn-gold px-8 py-4 rounded-xl text-base font-semibold"
              >
                Receber diagnóstico financeiro →
              </button>
              <button
                onClick={() => scrollTo("#como-funciona")}
                className="btn-outline-blue px-8 py-4 rounded-xl text-base"
              >
                Ver como funciona
              </button>
            </div>

            <p className="mt-5 text-xs text-white/25 animate-fade-in delay-300">
              Sem compromisso · Diagnóstico gratuito · Resposta em até 24h
            </p>

            {/* Trust bar */}
            <div className="mt-16 pt-8 border-t border-white/8 flex flex-wrap justify-center gap-6 sm:gap-10 animate-fade-in delay-300">
              {[
                { value: "100%", label: "Dados organizados" },
                { value: "CFO", label: "Estratégico sob demanda" },
                { value: "360°", label: "Visão financeira real" },
              ].map((s, i) => (
                <div key={i} className="text-center">
                  <div style={{ fontFamily: "'Playfair Display', serif" }} className="text-2xl font-bold text-white mb-0.5">{s.value}</div>
                  <div className="text-xs text-white/35">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#040c1c] to-transparent" />
      </section>

      <ContatoModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
}
