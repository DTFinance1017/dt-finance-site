import { FadeIn } from "./FadeIn";
import { AlertTriangle, HelpCircle, Shuffle, FileSpreadsheet, Gauge, TrendingDown } from "lucide-react";

const dores = [
  {
    icon: <HelpCircle size={20} />,
    title: "Não sabe quanto realmente lucra",
    description: "O faturamento cresceu, mas a conta bancária não reflete isso. Você sabe quanto entra, mas não entende para onde vai.",
    color: "#ef4444",
  },
  {
    icon: <Gauge size={20} />,
    title: "Sem previsibilidade de caixa",
    description: "Cada mês é uma surpresa. Não dá para planejar contratar, investir ou crescer sem saber o que esperar do próximo trimestre.",
    color: "#d97706",
  },
  {
    icon: <Shuffle size={20} />,
    title: "Pessoa física misturada com jurídica",
    description: "Gastos pessoais e empresariais no mesmo extrato. Isso distorce a visão do negócio e impede a apuração real das margens.",
    color: "#ef4444",
  },
  {
    icon: <FileSpreadsheet size={20} />,
    title: "Planilhas que ninguém mais entende",
    description: "Dados em diferentes arquivos, atualização manual, sem padrão. Quanto mais cresce, mais o controle fica para trás.",
    color: "#d97706",
  },
  {
    icon: <TrendingDown size={20} />,
    title: "Decisões baseadas em sensação",
    description: "\"Acho que tá indo bem.\" \"Parece que o mês foi bom.\" Sem dados estruturados, você decide no escuro — e o risco é alto.",
    color: "#ef4444",
  },
  {
    icon: <AlertTriangle size={20} />,
    title: "Crescimento sem estrutura financeira",
    description: "A empresa cresce, a complexidade aumenta e o controle não acompanha. Sem estrutura, crescer pode custar caro.",
    color: "#d97706",
  },
];

export function DorSection() {
  return (
    <section className="py-24 bg-[#040c1c] relative overflow-hidden">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 60% 50% at 50% 50%, rgba(239,68,68,0.04) 0%, transparent 70%)" }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <FadeIn className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#ef4444]/30 bg-[#ef4444]/8 text-[#f87171] text-xs font-medium mb-4">
            VOCÊ SE IDENTIFICA?
          </div>
          <h2
            style={{ fontFamily: "'Playfair Display', serif" }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight"
          >
            A maioria das PMEs opera
            <br />
            <span style={{ color: "#f87171" }}>no escuro financeiro</span>
          </h2>
          <p className="mt-4 text-white/50 max-w-xl mx-auto text-lg">
            Não por falta de esforço. Por falta de estrutura. E isso tem consequências reais.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {dores.map((d, i) => (
            <FadeIn key={i} delay={i * 70}>
              <div
                className="p-6 rounded-2xl border bg-[#060d1e] h-full"
                style={{ borderColor: `${d.color}20` }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: `${d.color}15`, color: d.color }}
                >
                  {d.icon}
                </div>
                <h3 className="text-sm font-semibold text-white mb-2 leading-snug">{d.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed">{d.description}</p>
              </div>
            </FadeIn>
          ))}
        </div>

        {/* Consequence strip */}
        <FadeIn delay={400}>
          <div
            className="mt-10 p-6 sm:p-8 rounded-2xl border text-center"
            style={{ borderColor: "rgba(239,68,68,0.2)", background: "linear-gradient(135deg, #0d0608, #100808)" }}
          >
            <p
              style={{ fontFamily: "'Playfair Display', serif" }}
              className="text-xl sm:text-2xl text-white font-semibold mb-2"
            >
              O resultado disso?
            </p>
            <p className="text-white/55 max-w-2xl mx-auto">
              Perda de dinheiro que você não percebe. Risco de caixa que aparece de surpresa. Decisões que custam o que poderiam render.{" "}
              <span className="text-white/80 font-medium">Isso tem solução.</span>
            </p>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
