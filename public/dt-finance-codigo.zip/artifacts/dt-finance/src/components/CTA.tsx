import { useState } from "react";
import { FadeIn } from "./FadeIn";
import { ContatoModal } from "./ContatoModal";
import { CheckCircle2 } from "lucide-react";

export function CTA() {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <>
      <section id="cta" className="py-24 bg-[#040c1c] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div
              className="relative rounded-3xl overflow-hidden p-10 sm:p-14 lg:p-16 border text-center"
              style={{
                borderColor: "rgba(30,64,175,0.4)",
                background: "linear-gradient(135deg, #060f24 0%, #07112a 50%, #040c1c 100%)",
              }}
            >
              <div
                className="absolute inset-0 pointer-events-none"
                style={{ background: "radial-gradient(ellipse 70% 60% at 50% 80%, rgba(240,192,64,0.08) 0%, transparent 70%)" }}
              />
              <div
                className="absolute inset-0 pointer-events-none"
                style={{ background: "radial-gradient(ellipse 80% 40% at 50% 0%, rgba(30,64,175,0.12) 0%, transparent 60%)" }}
              />

              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#f0c040]/30 bg-[#f0c040]/10 text-[#f0c040] text-xs font-medium mb-8">
                  DIAGNÓSTICO GRATUITO · SEM COMPROMISSO
                </div>

                <h2
                  style={{ fontFamily: "'Playfair Display', serif" }}
                  className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 max-w-3xl mx-auto leading-tight"
                >
                  Sua empresa merece saber
                  <br />
                  <span className="gradient-text">exatamente onde está</span>
                </h2>

                <p className="text-white/55 text-lg max-w-xl mx-auto mb-4">
                  Uma conversa sem enrolação: entendemos sua situação atual e mostramos o que seria possível com dados organizados.
                </p>
                <p className="text-white/35 text-sm max-w-lg mx-auto mb-10">
                  Não vendemos pacote antes de entender o problema. O primeiro passo é o diagnóstico.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    className="btn-gold px-10 py-4 rounded-xl text-base font-semibold glow-gold"
                    onClick={() => setModalOpen(true)}
                  >
                    Quero entender minha situação →
                  </button>
                  <button
                    className="btn-outline-blue px-8 py-4 rounded-xl text-base"
                    onClick={() => {
                      const el = document.querySelector("#como-funciona");
                      if (el) el.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    Ver como funciona
                  </button>
                </div>

                <p className="mt-5 text-sm text-white/30">
                  Resposta em até 24h · Nenhum dado financeiro exigido nesta etapa
                </p>

                {/* Checklist */}
                <div className="flex flex-wrap justify-center gap-x-8 gap-y-3 mt-10 pt-8 border-t border-white/8">
                  {[
                    "Diagnóstico financeiro gratuito",
                    "Sem burocracia inicial",
                    "Proposta só se fizer sentido",
                    "Confidencialidade total",
                  ].map((tag) => (
                    <span key={tag} className="flex items-center gap-2 text-xs text-white/40">
                      <CheckCircle2 size={12} className="text-emerald-400/60 flex-shrink-0" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      <ContatoModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
}
